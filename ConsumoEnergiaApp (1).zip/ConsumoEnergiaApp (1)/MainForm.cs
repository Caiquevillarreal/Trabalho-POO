
using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;
using System.Windows.Forms;
using ConsumoEnergia.Models;
// using ConsumoEnergia.Data;

namespace ConsumoEnergia
{
    public partial class MainForm : Form
    {
        private List<Consumidor> consumidores = new();
        private string caminhoArquivo = "Data/consumidores.json";

        public MainForm()
        {
            InitializeComponent();
            CarregarDados();
        }

        private void btnCadastrar_Click(object sender, EventArgs e)
        {
            var consumidor = new Consumidor
            {
                Nome = txtNome.Text,
                Documento = txtDocumento.Text
            };

            consumidor.Contas.Add(new ContaEnergia
            {
                IdInstalacao = txtInstalacao.Text,
                Tipo = rdbResidencial.Checked ? TipoConta.Residencial : TipoConta.Comercial,
                LeituraAnterior = double.Parse(txtLeituraAnterior.Text),
                LeituraAtual = double.Parse(txtLeituraAtual.Text)
            });

            consumidores.Add(consumidor);
            SalvarDados();
            MessageBox.Show("Cadastro realizado!");
        }

        private void btnConsultar_Click(object sender, EventArgs e)
        {
            string doc = txtConsultaDocumento.Text;
            var consumidor = consumidores.Find(c => c.Documento == doc);
            if (consumidor != null && consumidor.Contas.Count > 0)
            {
                var conta = consumidor.Contas[0];
                txtConsumo.Text = conta.Consumo.ToString("F2") + " kWh";
                txtValorTotal.Text = "R$ " + conta.ValorTotal.ToString("F2");
                txtSemImposto.Text = "R$ " + conta.ValorSemImpostos.ToString("F2");
            }
            else
            {
                MessageBox.Show("Consumidor não encontrado ou sem contas cadastradas.");
            }
        }

        private void CarregarDados()
        {
            if (File.Exists(caminhoArquivo))
            {
                string json = File.ReadAllText(caminhoArquivo);
                consumidores = JsonSerializer.Deserialize<List<Consumidor>>(json);
            }
        }

        private void SalvarDados()
        {
            string json = JsonSerializer.Serialize(consumidores, new JsonSerializerOptions { WriteIndented = true });

            string diretorio = Path.GetDirectoryName(caminhoArquivo);
            if (!Directory.Exists(diretorio))
            {
                Directory.CreateDirectory(diretorio);
            }

            File.WriteAllText(caminhoArquivo, json);
        }

    }
}
