
namespace ConsumoEnergia
{
    partial class MainForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.txtNome = new System.Windows.Forms.TextBox();
            this.txtDocumento = new System.Windows.Forms.TextBox();
            this.txtInstalacao = new System.Windows.Forms.TextBox();
            this.txtLeituraAnterior = new System.Windows.Forms.TextBox();
            this.txtLeituraAtual = new System.Windows.Forms.TextBox();
            this.txtConsultaDocumento = new System.Windows.Forms.TextBox();
            this.txtConsumo = new System.Windows.Forms.TextBox();
            this.txtValorTotal = new System.Windows.Forms.TextBox();
            this.txtSemImposto = new System.Windows.Forms.TextBox();
            this.btnCadastrar = new System.Windows.Forms.Button();
            this.btnConsultar = new System.Windows.Forms.Button();
            this.rdbResidencial = new System.Windows.Forms.RadioButton();
            this.rdbComercial = new System.Windows.Forms.RadioButton();
            this.SuspendLayout();

            this.txtNome.Location = new System.Drawing.Point(12, 12);
            this.txtNome.PlaceholderText = "Nome";
            this.txtDocumento.Location = new System.Drawing.Point(12, 42);
            this.txtDocumento.PlaceholderText = "CPF/CNPJ";
            this.txtInstalacao.Location = new System.Drawing.Point(12, 72);
            this.txtInstalacao.PlaceholderText = "ID Instalação";
            this.txtLeituraAnterior.Location = new System.Drawing.Point(12, 102);
            this.txtLeituraAnterior.PlaceholderText = "Leitura Anterior";
            this.txtLeituraAtual.Location = new System.Drawing.Point(12, 132);
            this.txtLeituraAtual.PlaceholderText = "Leitura Atual";

            this.rdbResidencial.Text = "Residencial";
            this.rdbResidencial.Location = new System.Drawing.Point(12, 162);
            this.rdbComercial.Text = "Comercial";
            this.rdbComercial.Location = new System.Drawing.Point(120, 162);

            this.btnCadastrar.Text = "Cadastrar";
            this.btnCadastrar.Location = new System.Drawing.Point(12, 192);
            this.btnCadastrar.Click += new System.EventHandler(this.btnCadastrar_Click);

            this.txtConsultaDocumento.Location = new System.Drawing.Point(12, 230);
            this.txtConsultaDocumento.PlaceholderText = "Documento para consulta";
            this.btnConsultar.Text = "Consultar";
            this.btnConsultar.Location = new System.Drawing.Point(200, 230);
            this.btnConsultar.Click += new System.EventHandler(this.btnConsultar_Click);

            this.txtConsumo.Location = new System.Drawing.Point(12, 270);
            this.txtValorTotal.Location = new System.Drawing.Point(12, 300);
            this.txtSemImposto.Location = new System.Drawing.Point(12, 330);

            this.ClientSize = new System.Drawing.Size(400, 370);
            this.Controls.AddRange(new System.Windows.Forms.Control[] {
                this.txtNome, this.txtDocumento, this.txtInstalacao, this.txtLeituraAnterior,
                this.txtLeituraAtual, this.rdbResidencial, this.rdbComercial,
                this.btnCadastrar, this.txtConsultaDocumento, this.btnConsultar,
                this.txtConsumo, this.txtValorTotal, this.txtSemImposto
            });
            this.Text = "Controle de Energia";
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.TextBox txtNome, txtDocumento, txtInstalacao, txtLeituraAnterior, txtLeituraAtual;
        private System.Windows.Forms.TextBox txtConsultaDocumento, txtConsumo, txtValorTotal, txtSemImposto;
        private System.Windows.Forms.Button btnCadastrar, btnConsultar;
        private System.Windows.Forms.RadioButton rdbResidencial, rdbComercial;
    }
}
