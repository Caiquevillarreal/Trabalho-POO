
namespace ConsumoEnergia.Models
{
    public enum TipoConta { Residencial, Comercial }

    public class ContaEnergia
    {
        public string IdInstalacao { get; set; }
        public TipoConta Tipo { get; set; }
        public double LeituraAnterior { get; set; }
        public double LeituraAtual { get; set; }

        public double Consumo => LeituraAtual - LeituraAnterior;
        public double Tarifa => Tipo == TipoConta.Residencial ? 0.40 : 0.35;
        public double Contribuicao => 9.25;
        public double ValorSemImpostos => (Consumo * Tarifa) + Contribuicao;
        public double Imposto => Tipo == TipoConta.Residencial ? 0.3 : 0.18;
        public double ValorTotal => ValorSemImpostos * (1 + Imposto);
    }
}
