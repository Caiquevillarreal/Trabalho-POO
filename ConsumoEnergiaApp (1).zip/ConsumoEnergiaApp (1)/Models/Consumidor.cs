
using System.Collections.Generic;

namespace ConsumoEnergia.Models
{
    public class Consumidor
    {
        public string Nome { get; set; }
        public string Documento { get; set; } // CPF ou CNPJ
        public List<ContaEnergia> Contas { get; set; } = new List<ContaEnergia>();
    }
}
